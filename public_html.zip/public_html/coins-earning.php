<?php
session_start();
error_reporting(0);
require_once('includes/config.php');
$user_obj = new Cl_User();
if(strlen($_SESSION['login'])==0)
{   
	header('location:login.php');
}
require_once('includes/function.php');
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
			header('location:index.php');
		}else{
			$message="Product ID is invalid";
		}
	}
}
$uid = $_SESSION['id'];
$row = $user_obj->user_detail_byid($uid);
$id = $row['id'];
$user_type = $row['user_type'];
$gift_coins_balance =$row['gift_coins'];
/*Code of fetch how many time users have get coins in day*/
$result_data = $user_obj->times_of_coins_get($id);
$no_of_coins_get = $result_data['COUNT(1)'];
/*Code of fetch coins supplement details on request to admin by user id*/
$data123 = $user_obj->coins_supplement_details($user_type);
$minimum_gift_coins_value = $data123['minimum_gift_coins_value'];
?>
<script type="text/javascript">
	if (window.location.hash == '#_=_'){
		history.replaceState 
		? history.replaceState(null, null, window.location.href.split('#')[0])
		: window.location.hash = '';
	}
</script>
<!DOCTYPE html>
<html>
<head>
	<title>GiftCoins Earning Center</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php require_once('templates/common_css.php');?>	
<style>

	   .baner{
		   font-size:20px;
		   
		   font-family:Montserrat-regular;
	   }
       .p-t-40 {
    padding-top: 158px;
}
.note{
	color:red!important;
	font-size:12px;
}
.text_img {
    position: absolute;
    top: 50%;
    left: 35%;
    transform: translate(-50%, -50%);
    color: #fff;
}
#RCS:hover {
    text-decoration: none;
    color: #08a6cc !important;
}
</style>
</head>
<body class="animsition" onLoad="start()">
<?php require_once('templates/header.php');?>
<!-- Title Page -->
	<section class="p-t-40 p-b-50 flex-col-c-m Uearn" style="background-image: url(images/refer-earn1.png);">
		<h2 style="color:#fff;">
			Gift Coins Earning Center
		</h2>
	</section><br>
	<div class="container">
	<div class="row">
	     <div class="col-sm-4 col-md-4 col-xs-12 block1 hov-img-zoom pos-relative m-b-30">
		 <img src="images/req.png" alt="IMG-BENNER" style="width:350px">
					<div class="text_img">
						<h6 class="baner">Request Coin <br> Supplement</h6>
						<p style="color:yellow";>Reqest to admin</p>
						<?php if(($gift_coins_balance >= $minimum_gift_coins_value) AND $no_of_coins_get < 5) {?>
						<p><button type="submit" id="RCS" name="req_to_admin" class="" style="color:black;text-decoration:underline">Request Coin Supplement</button></p>
						<?php } else {?>
						<p><button type="submit" id="" name="" class="" style="color:black;text-decoration:none; cursor:none;">Already Requested</button></p>
						<?php }?>
						
						<p id="msg"><?php if(!empty($_SESSION['msg_status'])){?><?php echo htmlentities($_SESSION['msg_status']);?><?php echo htmlentities($_SESSION['msg_status']="");?><?php }?></p>
						<p class="note">*You can request 5 times per day <br/>*To avail this minimum <?php echo $minimum_gift_coins_value;?> gift coins reqired</p>
		 </div>
	</div>
		 <div class="col-sm-4 col-md-4 col-xs-12 block1 hov-img-zoom pos-relative m-b-30">
		 <img src="images/banner3.png" alt="IMG-BENNER" style="width:350px">
					<div class="text_img">
						<h6 class="baner">By Refer To Friend</h6>
						<p style="color:yellow";>connect with friend</p>
						<p><a href="refer_coin.php" target="_blank" style="color:black;text-decoration:underline">Discover Now</a></p>
		 </div>
	</div>
	<div class="col-sm-4 col-md-4 col-xs-12 block1 hov-img-zoom pos-relative m-b-30">
		 <img src="images/package.png" alt="IMG-BENNER" style="width:350px">
					<div class="text_img">
						<h6 class="baner">By Purchase <br>Coin</h6>
						<p style="color:yellow;">Get Coin</p>
						<p><a href="package.php" target="_blank" style="color:black;text-decoration:underline">Discover Now</a></p>
		 </div>
	</div>
	</div><br>
	<div class="row">
	     <div class="col-lg-2"></div>
	     <div class="col-sm-4 col-md-4 col-xs-12 block1 hov-img-zoom pos-relative m-b-30">
		 <img src="images/click.png" alt="IMG-BENNER" style="width:350px">
					<div class="text_img">
						<h6 class="baner">By Click Link</h6>
						<p style="color:yellow";>Connect with Friend</p>
						<p><a href="clickbank-products.php" target="_blank" style="color:black;text-decoration:underline">Discover Now</a></p>
		 </div>
	    </div>
		 <div class="col-sm-4 col-md-4 col-xs-12 block1 hov-img-zoom pos-relative m-b-30">
		 <img src="images/share.png" alt="IMG-BENNER" style="width:350px">
					<div class="text_img">
						<h6 class="baner">By Share To Friend</h6>
						<p style="color:yellow";>Share is Care</p>
						<p><a href="" target="_blank" style="color:black;text-decoration:underline">Discover Now</a></p>
		 </div>
	</div>
	 <div class="col-lg-2"></div>
	</div>
	
	</div>
	</div>
<?php require_once('templates/common_js.php');?>
<?php require_once('templates/footer.php');?>
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="js/jquery.easy-ticker.js"></script> 
<script type="text/javascript">
   $(function(){	
   	$('.demo5').easyTicker({
   		direction: 'up',
   		visible: 3,
   		interval: 1000,
   		controls: {
   			up: '.btnUp',
   			down: '.btnDown',
   			toggle: '.btnToggle'}
   	});
   });
</script>
<script type="text/javascript">
	$(document).ready(function() {
		var jq = $.noConflict();
		jq("#RCS").click(function(){
			//alert('dtrt');
				//var name = $("#name").val();
				//var email = $("#email").val();
				var name = 'preet';
				var name1= 'mtharu';
				var dataString = 'name='+ name + '&name1='+ name1;
					jq.ajax({
						url : 'coins_supplement.php', 
						type : 'post',
						data: dataString,
						success : function(data){
							jq("#msg").html(data);
						 window.setTimeout(function(){location.reload()},3000);
					}
				});		
			});
	});
</script>
</body>
</html>