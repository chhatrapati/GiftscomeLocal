<?php session_start();
include('includes/config.php');
?>
<?php
//echo '<pre>';print_r($_SESSION); die();
// code for insert product in order table
$uid= $_SESSION['id'];
$ret=mysqli_query($con,"select game_coins, gift_coins from users where id=$uid");
$row=mysqli_fetch_array($ret);
$user_balance = $row['game_coins'];
$_SESSION['game_coins'] = $user_balance;
if(isset($_POST['ordersubmit'])) 
{
	//echo '<pre>';print_r($_SESSION); die();
    $quantity=$_SESSION['product_quantity'];
    $pdd=$_SESSION['product_id'];
	
	$_SESSION['tp'] = $_SESSION['tp'];
	
if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
elseif($_SESSION['tp'] <= $_SESSION['game_coins'])
{
header('location:payment-method.php');
}
else
{
	echo "<script>alert('Your Balance is not enough to purchase items');</script>";
	//header('location:index.php');
}
}
?>
<!DOCTYPE html>
<head>
	<title>Home</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php require_once('templates/common_css.php');?>
</head>
<body class="animsition">
<?php require_once('templates/header.php');?>
	
	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url(images/gamesbanner1.png);">
		<h2 class="l-text2 t-center">
			Cart
		</h2>
	</section>
	<!-- Cart -->
	<section class="cart bgwhite p-t-70 p-b-100">
		<div class="container">
		 <div class="container-table-cart">
                            <div id="appned_tabel" class="wrap-table-shopping-cart bgwhite">
                                <table class="table-shopping-cart">
                                    <tr class="table-head">
                                        <th class="column-1">Product Image</th>
                                        <th class="column-2">Product</th>
                                        <th class="column-4 p-l-70">Quantity</th>
                                        <th class="column-3">Price (In Coins)</th>
                                        <th class="column-5">Total</th>
                                    </tr> 
                                    <?php //echo '<pre>'; print_r($_SESSION["shopping_cart"]);
                                    if (!empty($_SESSION["shopping_cart"])) {
                                        $total = 0;
                                        foreach ($_SESSION["shopping_cart"] as $keys => $values) {
                                            ?>  
                                            <tr class="table-row">
                                                <td class="column-1">
                                                    <div class="cart-img-product b-rad-4 o-f-hidden">
                                                        <img src="admin/productimages/<?php echo $values["product_name"];?>/<?php echo $values["product_image"];?>" alt="IMG-PRODUCT">
                                                    </div>
                                                </td>
                                                <td class="column-2"><?php echo $values["product_name"]; ?></td>
												
                                                <td class="column-4">
                                                    <input type="button" name="quantityP[]" id="quantity<?php echo $values["product_id"]; ?>"  data-product_id="<?php echo $values["product_id"]; ?>" value="+" style="font-size:14pt;border:1px solid #f00;padding:10px;background-color:#45445" class="quantity" />
                                                    <input type="text" name="quantityVal[]" id="quantityVal<?php echo $values["product_id"]; ?>" value="<?php echo $values["product_quantity"]; ?>"  class="quantityVal"  style="margin:0 0px 0 9px;width:25px;"/>
                                                    <input type="button" name="quantityM[]" id="quantityM<?php echo $values["product_id"]; ?>"  data-product_id="<?php echo $values["product_id"]; ?>" value="-" style="font-size:14pt;border:1px solid #f00;padding:10px;background-color:#45445" class="quantityM" />
                                                </td>  
                                                <td class="column-3"><?php echo $values["product_price"]; ?></td>  
                                                <td align="right"><?php echo $values["product_quantity"] * $values["product_price"]; ?> <button name="delete" class="btn btn-danger btn-xs delete" id="<?php echo $values["product_id"]; ?>"><i class="fa fa-remove"></i></button></td>  
                                                 
                                            </tr>  
        <?php
        $total = $total + ($values["product_quantity"] * $values["product_price"]);
		$_SESSION['tp'] = $total;
		$_SESSION['product_quantity'] = $values["product_quantity"];
		$_SESSION['product_id'] = $values["product_id"];
    }
    ?>  
                                        <tr>  
                                            <td colspan="3" align="right"><span class="m-text22 w-size19 w-full-sm">Total:</span></td>  
                                            <td align="right"><?php echo $total; ?></td>  
                                            <td></td>  
                                        </tr>  
                                         
    <?php } else { ?>  
	<script type="text/javascript">
					setTimeout(function () {
					var basepath = window.location.protocol + '//' + window.location.hostname;
					var path = basepath + '/product.php';
					window.location.href= path; // the redirect goes here
					},1000); // 5 seconds
</script>
	<?php }?>
                                </table>
								</div>  
                        </div>
								<!-- Total -->
			<div class="w-size18 p-l-40 p-r-40 p-t-30 p-b-38 m-t-30 m-r-0 m-l-auto p-lr-15-sm">
			
				<div class="size15 trans-0-4">
					<!-- Button -->
					<form method="post" action="" style="display:inline;">
					<button type="submit" name="ordersubmit"  class="flex-c-m sizefull bg1 bo-rad-23 hov1 s-text1 trans-0-4">
						Proceed to Checkout
					</button>
					</form>
				</div>
			</div>						
		</div>
	</section>
<?php require_once('templates/footer.php');?>
<?php require_once('templates/common_js.php');?>
 <script>
                            $(document).ready(function (data) {
                                $('.add_to_cart').click(function () {
                                    var product_id = $(this).attr("id");
                                    var product_name = $('#name' + product_id).val();
                                    var product_price = $('#price' + product_id).val();
                                    var product_quantity = $('#quantity' + product_id).val();
                                    var action = "add";
                                    if (product_quantity > 0)
                                    {
                                        $.ajax({
                                            url: "action.php",
                                            method: "POST",
                                            dataType: "json",
                                            data: {
                                                product_id: product_id,
                                                product_name: product_name,
                                                product_price: product_price,
                                                product_quantity: product_quantity,
                                                action: action
                                            },
                                            success: function (data)
                                            {
                                                $('#order_table').html(data.order_table);
                                                $('.badge').text(data.cart_item);
                                                alert("Product has been Added into Cart");
                                            }
                                        });
                                    } else
                                    {
                                        alert("Please Enter Number of Quantity")
                                    }
                                });
                                $(document).on('click', '.delete', function () {
                                    var product_id = $(this).attr("id");
                                    var action = "remove";
                                    if (confirm("Are you sure you want to remove this product?"))
                                    {
                                        $.ajax({
                                            url: "action.php",
                                            method: "POST",
                                            dataType: "json",
                                            data: {product_id: product_id, action: action},
                                            success: function (data) {
												 $('#order_table').html(data.order_table2);
                                                $('#appned_tabel').html(data.order_table);
                                               // $('.badge').text(data.cart_item);
                                            }
                                        });
                                    } else
                                    {
                                        return false;
                                    }
                                });
//                                $(document).on('keyup', '.quantity', function () {
                                $(document).on('click', '.quantity', function () {
                                    var product_id = $(this).data("product_id");
                                    //var quantity = $(this).val();
                                    var quantity = parseInt($("#quantityVal"+product_id).val())+1;
                                    var action = "quantity_change";
                                    if (quantity != '')
                                    {
                                        $.ajax({
                                            url: "action.php",
                                            method: "POST",
                                            dataType: "json",
                                            data: {product_id: product_id, quantity: quantity, action: action},
                                            success: function (data) {
                                                $('#appned_tabel').empty();
												$('#appned_tabel').html(data.order_table);
												$('#order_table').html(data.order_table1);
                                            }
                                        });
                                    }
                                });
                                $(document).on('click', '.quantityM', function () {
                                    var product_id = $(this).data("product_id");
                                    //var quantity = $(this).val();
                                    
                                    if((parseInt($("#quantityVal"+product_id).val())-1)==0)
                                    {
                                        var quantity = 0;
                                    }
                                    else
                                    {
                                        var quantity = parseInt($("#quantityVal"+product_id).val())-1;
                                    }
                                    
                                    var action = "quantity_change";
                                    if (quantity != '')
                                    {
                                        $.ajax({
                                            url: "action.php",
                                            method: "POST",
                                            dataType: "json",
                                            data: {product_id: product_id, quantity: quantity, action: action},
                                            success: function (data) {
												
                                                $('#appned_tabel').html(data.order_table);
												$('#order_table').html(data.order_table1);
                                            }
                                        });
                                    }
                                });
                            });
                        </script>
</body>
</html>