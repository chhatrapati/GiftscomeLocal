<?php
session_start();
require_once 'includes/config.php'; 
include ('function.php');

$email = $_GET['email'];
$token = $_GET['token'];

$userID = UserID($email); 

$verifytoken = verifytoken($userID, $token);
if(isset($_POST['submit']))
{
	$new_password = $_POST['new_password'];
	$new_password = md5($new_password);
	$retype_password = $_POST['retype_password'];
	$retype_password = md5($retype_password);
	if($new_password == $retype_password)
	{
		$update_password = mysqli_query($con, "UPDATE users SET password = '$new_password' WHERE id = $userID");
		if($update_password)
		{
				mysqli_query($con, "UPDATE recovery_keys SET valid = 0 WHERE userID = $userID AND token ='$token'");
				$msg = 'Your password has changed successfully. Please login with your new passowrd.';
				$msgclass = 'bg-success';
				echo "<script>window.location.href = 'login.php';</script>";
		}
	}else
	{
		 $msg = "Password doesn't match";
		 $msgclass = 'bg-danger';
	}
	
}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Smart Foreget Passowrd</title>
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/elegant-font/html-css/style.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<?php require_once('templates/common_css.php');?>
<!--===============================================================================================-->
	<!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
   <style>
     .pw{
		 text-align:center;
		 padding-top:10px;
		 color:skyblue;
	 }
	 .form-control {
    display: block;
    width: 66%;
    height: 34px;
    padding: 6px 17px;
    font-size: 14px;
    margin-left: 130px;
    margin-top: 19px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc !important;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}
.btn-info {
    color: #fff;
    background-color: #5bc0de;
    border-color: #46b8da;
	margin-left:40%;
}
.footer_bt {
    padding: 20px;
    color: #000;
    background-color:#eee;
}

   </style>
  </head>
<body class="animsition">
<?php require_once('templates/header.php'); ?>




<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url(images/login_banner1.jpg);">
		<h2 class="l-text2 t-center" style="margin-left:10%;">
			Reset Your Password
		</h2>
	</section>
<section class="bgwhite p-t-66 p-b-38">
		<div class="container">
	    <div class="row">
		<div class="login-form">
			<div class="form-header">
				<i class="fa fa-user"></i>
			</div>
			<div>
				<?php if($verifytoken == 1) { ?>
				<h3 class="pw">Reset Your Password</h3>
				<div class="">
						<form class="form-horizontal" role="form" id="password-set" method="post" >
								<?php if(isset($msg)) { ?>
								<div class="<?php echo $msgclass; ?>" style="padding:5px;"><?php echo $msg; ?></div>
								<?php } ?>
								<fieldset>
								<div class="container">
								<label class="formsy-input required">
								<div class="input-wrap pass-error">
										<input class="form-control" name="new_password" id="new_password" type="password"  pattern=".{8,}"   required title="8 characters minimum" placeholder="New Password" required>
										<span class="error"></span> </div>
								</label><br>
								<label class="formsy-input required">
									<div class="input-wrap pass-error">
												<input class="form-control" name="retype_password" id="retype_password" type="password" placeholder="Re-type New Password" required>
										<span class="error"></span> </div>
								</label>
								</div>
								
												<button class="btn btn-info" name="submit" style="margin-top:8px;"><span>Submit</span></button>
										</fieldset>
						</form>
				</div>
				<?php }else {?>
				<div class="col-lg-12">
						<h1><span>Link is expired or Used</span></h1>
						<p>Opps! The link you have come with is maybe expired or already used. Please make sure that you copied the link correctly or request another token from <a href="/password_new.php">here</a>.</p>
				</div>
				<?php }?>
		</div>
		
		</div>
	</div></div>
	</section>

<?php require_once('templates/footer.php');?>
	<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
	<script type="text/javascript">
		$(".selection-1").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});

		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect2')
		});
	</script>

	<script src="js/main.js"></script>
	<!-- /container -->
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
  </body>
</html>