<?php
//error_reporting(0);
include('includes/config.php');
//extract($_POST);
$id=$_POST['id'];
$status=$_POST['status'];
$query=mysqli_query($con,"UPDATE tbl_user_robot set  status='".$status."' WHERE id='".$id."'");
?>