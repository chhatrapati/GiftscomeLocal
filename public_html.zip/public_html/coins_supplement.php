<?php
session_start();
//error_reporting(0);
include('includes/config.php');
$user_obj = new Cl_User();
//$name=$_POST['name'];
//$name1=$_POST['name1'];
 //echo $name;
 //echo $name1;
$user_obj->coins_by_request_to_admin();
$_SESSION['msg_status']="You have received coins";
//echo 'You have received coins';
?>
<script>
 $(document).ready(function(){
        setTimeout(function() {
          $('#msg').fadeOut('fast');
        }, 1000);
    });
</script>