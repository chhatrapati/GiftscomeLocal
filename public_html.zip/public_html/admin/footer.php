	<div class="row-fluid">
  <div id="footer" class="span12"> &copy; 2017 Gift Coins </b> All rights reserved. </div>
</div>