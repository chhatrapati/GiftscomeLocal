<?php
$mysql_hostname = "localhost";
$mysql_user = "giftscom_user1";
$mysql_password = "Codechefs@2018";
$mysql_database = "giftscom_gc";
$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password,$mysql_database)
or die("Oops some thing went wrong");
?>