<div id="sidebar"> <a href="#" class="visible-phone"><i class="icon icon-list"></i>Forms</a>
  <ul id="user-menu">
    <li><a href="view_users.php?id=<?php echo toPublicId($_SESSION['id']);?>"><i class="fa fa-user"></i> <span>View Users Profile</span></a> </li>
    <li><a href="user_logout.php"><i class="fa fa-sign-out"></i>Logout </a></li>
                                <!--<li><a href="subcategory.php"><i class="menu-icon icon-tasks"></i>Sub Category </a></li>-->
                                

							
  </ul>
</div>