<?php session_start();?>
<!DOCTYPE html>
<head>
	<title>About</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<?php require_once('templates/common_css.php');?>
</head>
<body class="animsition" onLoad="start()">
<?php require_once('templates/header.php');?>
	<!-- Title Page -->
	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url(images/about_banner.png);">
	</section>
	<!-- content page -->
	<section class="bgwhite p-t-66 p-b-38">
		<div class="container">
			<div class="row">
			<?php
							$query = "SELECT * FROM  about";
							$result = mysqli_query($con, $query) or die(mysqli_error($con));
					        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
							
							$about_id=$row['about_id'];
							$about_image=$row['about_image'];
							$about_description=$row['about_description'];
							$about_tagline=$row['about_tagline'];
							$about_writer=$row['about_writer'];
			?>
				<div class="col-md-4 p-b-30">
					<div class="hov-img-zoom">
						<img src="images/<?php echo $about_image;?>" alt="IMG-ABOUT">
					</div>
				</div>

				<div class="col-md-8 p-b-30">
					<h3 class="m-text26 p-t-15 p-b-16">
						Our story
					</h3>

					<p class="p-b-28">
					<?php echo $about_description;?>
					</p>

					<div class="bo13 p-l-29 m-l-9 p-b-10">
						<p class="p-b-11">
						<?php echo $about_tagline;?>
						</p>

						<span class="s-text7">
							- <?php echo $about_writer;?>
						</span>
					</div>
				</div>
							<?php } ?>
			</div>
		</div>
	</section>
<?php require_once('templates/footer.php');?>
<?php require_once('templates/common_js.php');?>
</body>
</html>