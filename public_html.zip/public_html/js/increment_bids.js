function myFunction() {
	var slcVal = $("#slc").val();
    var pay_amt0Val = document.getElementById("payout_amount0").value;
    var FinalValue0 = +pay_amt0Val + +slcVal;
    document.getElementById("payout_amount0").value  = FinalValue0;
	
	var pay_amtVal1 = document.getElementById("payout_amount1").value;
    var FinalValue1 = +pay_amtVal1 + +slcVal;
    document.getElementById("payout_amount1").value = FinalValue1;
	
	var pay_amtVal2 = document.getElementById("payout_amount2").value;
    var FinalValue2 = +pay_amtVal2 + +slcVal;
    document.getElementById("payout_amount2").value = FinalValue2;
	
	var pay_amtVal3 = document.getElementById("payout_amount3").value;
    var FinalValue3 = +pay_amtVal3 + +slcVal;
    document.getElementById("payout_amount3").value = FinalValue3;
	
	var pay_amtVal4 = document.getElementById("payout_amount4").value;
    var FinalValue4 = +pay_amtVal3 + +slcVal;
    document.getElementById("payout_amount4").value = FinalValue4;
	
	var pay_amtVal5 = document.getElementById("payout_amount5").value;
    var FinalValue5 = +pay_amtVal5 + +slcVal;
    document.getElementById("payout_amount5").value = FinalValue5;
	
	var pay_amtVal6 = document.getElementById("payout_amount6").value;
    var FinalValue6 = +pay_amtVal6 + +slcVal;
    document.getElementById("payout_amount6").value = FinalValue6;
	
	var pay_amtVal7 = document.getElementById("payout_amount7").value;
    var FinalValue7 = +pay_amtVal7 + +slcVal;
    document.getElementById("payout_amount7").value = FinalValue7;
	
	var pay_amtVal8 = document.getElementById("payout_amount8").value;
    var FinalValue8 = +pay_amtVal8 + +slcVal;
    document.getElementById("payout_amount8").value = FinalValue8;
	
	var pay_amtVal9 = document.getElementById("payout_amount9").value;
    var FinalValue9 = +pay_amtVal9 + +slcVal;
    document.getElementById("payout_amount9").value = FinalValue9;
	
	var pay_amtVal10 = document.getElementById("payout_amount10").value;
    var FinalValue10 = +pay_amtVal10 + +slcVal;
    document.getElementById("payout_amount10").value = FinalValue10;
	
	var pay_amtVal11 = document.getElementById("payout_amount11").value;
    var FinalValue11 = +pay_amtVal11 + +slcVal;
    document.getElementById("payout_amount11").value = FinalValue11;
	
	var pay_amtVal12 = document.getElementById("payout_amount12").value;
    var FinalValue12 = +pay_amtVal12 + +slcVal;
    document.getElementById("payout_amount12").value = FinalValue12;
	
	var pay_amtVal13 = document.getElementById("payout_amount13").value;
    var FinalValue13 = +pay_amtVal13 + +slcVal;
    document.getElementById("payout_amount13").value = FinalValue13;
	
	var pay_amtVal14 = document.getElementById("payout_amount14").value;
    var FinalValue14 = +pay_amtVal14 + +slcVal;
    document.getElementById("payout_amount14").value = FinalValue14;
	
	var pay_amtVal15 = document.getElementById("payout_amount15").value;
    var FinalValue15 = +pay_amtVal15 + +slcVal;
    document.getElementById("payout_amount15").value = FinalValue15;
	
	var pay_amtVal16 = document.getElementById("payout_amount16").value;
    var FinalValue16 = +pay_amtVal16 + +slcVal;
    document.getElementById("payout_amount16").value = FinalValue16;
	
	var pay_amtVal17 = document.getElementById("payout_amount17").value;
    var FinalValue17 = +pay_amtVal17 + +slcVal;
    document.getElementById("payout_amount17").value = FinalValue17;
	
	var pay_amtVal18 = document.getElementById("payout_amount18").value;
    var FinalValue18 = +pay_amtVal18 + +slcVal;
    document.getElementById("payout_amount18").value = FinalValue18;
	
	var pay_amtVal19 = document.getElementById("payout_amount19").value;
    var FinalValue19 = +pay_amtVal19 + +slcVal;
    document.getElementById("payout_amount19").value = FinalValue19;
	
	var pay_amtVal20 = document.getElementById("payout_amount20").value;
    var FinalValue20 = +pay_amtVal20 + +slcVal;
    document.getElementById("payout_amount20").value = FinalValue20;
	
	var pay_amtVal21 = document.getElementById("payout_amount21").value;
    var FinalValue21 = +pay_amtVal21 + +slcVal;
    document.getElementById("payout_amount21").value = FinalValue21;
	
	var pay_amtVal22 = document.getElementById("payout_amount22").value;
    var FinalValue22 = +pay_amtVal22 + +slcVal;
    document.getElementById("payout_amount22").value = FinalValue22;
	
	var pay_amtVal23 = document.getElementById("payout_amount23").value;
    var FinalValue23 = +pay_amtVal23 + +slcVal;
    document.getElementById("payout_amount23").value = FinalValue23;
	
	var pay_amtVal24 = document.getElementById("payout_amount24").value;
    var FinalValue24 = +pay_amtVal24 + +slcVal;
    document.getElementById("payout_amount24").value = FinalValue24;
	
	var pay_amtVal25 = document.getElementById("payout_amount25").value;
    var FinalValue25 = +pay_amtVal25 + +slcVal;
    document.getElementById("payout_amount25").value = FinalValue25;
	
	
	var pay_amtVal26 = document.getElementById("payout_amount26").value;
    var FinalValue26 = +pay_amtVal26 + +slcVal;
    document.getElementById("payout_amount26").value = FinalValue26;
	
	var pay_amtVal27 = document.getElementById("payout_amount27").value;
    var FinalValue27 = +pay_amtVal27 + +slcVal;
    document.getElementById("payout_amount27").value = FinalValue27;
	todo();
}

  $(document).ready(function() {
	  $('#MyButton').click(function(){
	var slcVal = $("#coin_add").val();
    var pay_amt0Val = document.getElementById("payout_amount0").value;
    var FinalValue0 = +pay_amt0Val + +slcVal;
    document.getElementById("payout_amount0").value  = FinalValue0;
	
	var pay_amtVal1 = document.getElementById("payout_amount1").value;
    var FinalValue1 = +pay_amtVal1 + +slcVal;
    document.getElementById("payout_amount1").value = FinalValue1;
	
	var pay_amtVal2 = document.getElementById("payout_amount2").value;
    var FinalValue2 = +pay_amtVal2 + +slcVal;
    document.getElementById("payout_amount2").value = FinalValue2;
	
	var pay_amtVal3 = document.getElementById("payout_amount3").value;
    var FinalValue3 = +pay_amtVal3 + +slcVal;
    document.getElementById("payout_amount3").value = FinalValue3;
	
	var pay_amtVal4 = document.getElementById("payout_amount4").value;
    var FinalValue4 = +pay_amtVal3 + +slcVal;
    document.getElementById("payout_amount4").value = FinalValue4;
	
	var pay_amtVal5 = document.getElementById("payout_amount5").value;
    var FinalValue5 = +pay_amtVal5 + +slcVal;
    document.getElementById("payout_amount5").value = FinalValue5;
	
	var pay_amtVal6 = document.getElementById("payout_amount6").value;
    var FinalValue6 = +pay_amtVal6 + +slcVal;
    document.getElementById("payout_amount6").value = FinalValue6;
	
	var pay_amtVal7 = document.getElementById("payout_amount7").value;
    var FinalValue7 = +pay_amtVal7 + +slcVal;
    document.getElementById("payout_amount7").value = FinalValue7;
	
	var pay_amtVal8 = document.getElementById("payout_amount8").value;
    var FinalValue8 = +pay_amtVal8 + +slcVal;
    document.getElementById("payout_amount8").value = FinalValue8;
	
	var pay_amtVal9 = document.getElementById("payout_amount9").value;
    var FinalValue9 = +pay_amtVal9 + +slcVal;
    document.getElementById("payout_amount9").value = FinalValue9;
	
	var pay_amtVal10 = document.getElementById("payout_amount10").value;
    var FinalValue10 = +pay_amtVal10 + +slcVal;
    document.getElementById("payout_amount10").value = FinalValue10;
	
	var pay_amtVal11 = document.getElementById("payout_amount11").value;
    var FinalValue11 = +pay_amtVal11 + +slcVal;
    document.getElementById("payout_amount11").value = FinalValue11;
	
	var pay_amtVal12 = document.getElementById("payout_amount12").value;
    var FinalValue12 = +pay_amtVal12 + +slcVal;
    document.getElementById("payout_amount12").value = FinalValue12;
	
	var pay_amtVal13 = document.getElementById("payout_amount13").value;
    var FinalValue13 = +pay_amtVal13 + +slcVal;
    document.getElementById("payout_amount13").value = FinalValue13;
	
	var pay_amtVal14 = document.getElementById("payout_amount14").value;
    var FinalValue14 = +pay_amtVal14 + +slcVal;
    document.getElementById("payout_amount14").value = FinalValue14;
	
	var pay_amtVal15 = document.getElementById("payout_amount15").value;
    var FinalValue15 = +pay_amtVal15 + +slcVal;
    document.getElementById("payout_amount15").value = FinalValue15;
	
	var pay_amtVal16 = document.getElementById("payout_amount16").value;
    var FinalValue16 = +pay_amtVal16 + +slcVal;
    document.getElementById("payout_amount16").value = FinalValue16;
	
	var pay_amtVal17 = document.getElementById("payout_amount17").value;
    var FinalValue17 = +pay_amtVal17 + +slcVal;
    document.getElementById("payout_amount17").value = FinalValue17;
	
	var pay_amtVal18 = document.getElementById("payout_amount18").value;
    var FinalValue18 = +pay_amtVal18 + +slcVal;
    document.getElementById("payout_amount18").value = FinalValue18;
	
	var pay_amtVal19 = document.getElementById("payout_amount19").value;
    var FinalValue19 = +pay_amtVal19 + +slcVal;
    document.getElementById("payout_amount19").value = FinalValue19;
	
	var pay_amtVal20 = document.getElementById("payout_amount20").value;
    var FinalValue20 = +pay_amtVal20 + +slcVal;
    document.getElementById("payout_amount20").value = FinalValue20;
	
	var pay_amtVal21 = document.getElementById("payout_amount21").value;
    var FinalValue21 = +pay_amtVal21 + +slcVal;
    document.getElementById("payout_amount21").value = FinalValue21;
	
	var pay_amtVal22 = document.getElementById("payout_amount22").value;
    var FinalValue22 = +pay_amtVal22 + +slcVal;
    document.getElementById("payout_amount22").value = FinalValue22;
	
	var pay_amtVal23 = document.getElementById("payout_amount23").value;
    var FinalValue23 = +pay_amtVal23 + +slcVal;
    document.getElementById("payout_amount23").value = FinalValue23;
	
	var pay_amtVal24 = document.getElementById("payout_amount24").value;
    var FinalValue24 = +pay_amtVal24 + +slcVal;
    document.getElementById("payout_amount24").value = FinalValue24;
	
	var pay_amtVal25 = document.getElementById("payout_amount25").value;
    var FinalValue25 = +pay_amtVal25 + +slcVal;
    document.getElementById("payout_amount25").value = FinalValue25;
	
	
	var pay_amtVal26 = document.getElementById("payout_amount26").value;
    var FinalValue26 = +pay_amtVal26 + +slcVal;
    document.getElementById("payout_amount26").value = FinalValue26;
	
	var pay_amtVal27 = document.getElementById("payout_amount27").value;
    var FinalValue27 = +pay_amtVal27 + +slcVal;
    document.getElementById("payout_amount27").value = FinalValue27;
	todo();
});
});

$(document).ready(function() {
	  $('#clear').click(function(){
    document.getElementById("payout_amount0").value  = '00';
    document.getElementById("payout_amount1").value = '00';
    document.getElementById("payout_amount2").value = '00';
    document.getElementById("payout_amount3").value = '00';
    document.getElementById("payout_amount4").value = '00';
    document.getElementById("payout_amount5").value = '00';
    document.getElementById("payout_amount6").value = '00';
    document.getElementById("payout_amount7").value = '00';
    document.getElementById("payout_amount8").value = '00';
    document.getElementById("payout_amount9").value = '00';
    document.getElementById("payout_amount10").value = '00';
    document.getElementById("payout_amount11").value = '00';
    document.getElementById("payout_amount12").value = '00';
    document.getElementById("payout_amount13").value = '00';
    document.getElementById("payout_amount14").value = '00';
    document.getElementById("payout_amount15").value = '00';
    document.getElementById("payout_amount16").value = '00';
    document.getElementById("payout_amount17").value = '00';
    document.getElementById("payout_amount18").value = '00';
    document.getElementById("payout_amount19").value = '00';
    document.getElementById("payout_amount20").value = '00';
    document.getElementById("payout_amount21").value = '00';
    document.getElementById("payout_amount22").value = '00';
    document.getElementById("payout_amount23").value = '00';
    document.getElementById("payout_amount24").value = '00';
    document.getElementById("payout_amount25").value = '00';	
    document.getElementById("payout_amount26").value = '00';
    document.getElementById("payout_amount27").value = '00';
	todo();
});
});