<?php session_start();?>
<!DOCTYPE html>
<head>
	<title>Contact</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
<?php require_once('templates/common_css.php');?>
<style>
.row {
    margin-right: 0px;
}
</style>
</head>
<body class="animsition">
<?php require_once('templates/header.php');?>

<!-- Title Page -->
	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url(images/Contact.jpg);">
		<h2 class="l-text2 t-center">
			Contact
		</h2>
	</section>

	<!-- content page -->
	<section class="bgwhite p-t-66">
		<div class="container">
			<div class="row">
					<div class="col-md-6 p-b-30">					
						<h4 class="m-text26 p-b-36 p-t-15">
							Send us your message
						</h4>
                   <form class="leave-comment" id="myform" method="post" enctype="multipart/form-data">
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="name" placeholder="Full Name" required>
						</div>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="subject" placeholder="Subject" required>
						</div>

						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="mobile" placeholder="Phone Number" required>
						</div>

						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="email" placeholder="Email Address" required>
						</div>

						<textarea class="dis-block s-text7 size20 bo4 p-l-22 p-r-22 p-t-13 m-b-20" name="message" placeholder="Message"></textarea>

						<div class="w-size25">
							<!-- Button -->
							<button class="flex-c-m size2 bg1 bo-rad-23 hov1 m-text3 trans-0-4" type="submit" name="send_email" value="Send" ><i class="fa fa-paper-plane" aria-hidden="true" style="padding-right:10px "></i>Send</button>
						</div>
					</form>
					<?php
if (isset($_POST['send_email'])){
       
	require_once 'class.phpmailer.php';
	require_once 'PHPMailerAutoload.php';
	require_once 'class.smtp.php';
	$mail = new PHPMailer();
	// Now you only need to add the necessary stuff
	 
	// HTML body
	 $name=$_POST['name'];
	 $email=$_POST['email'];
	 $mobile=$_POST['mobile'];
	 $subject=$_POST['subject'];
	 $message=$_POST['message'];
	 
	 $message1 .= '<div style="width: 600px; float: left;">
		<h1>Email: <b>'.$email.'</b></h1>';
		
	$message1 .= '<div style="width: 600px; float: left;">
		<h1>Mobile: <b>'.$mobile.'</b></h1>';
		
		$message1 .= '<div style="width: 600px; float: left;">
		<h1>Message: <b>'.$message.'</b></h1>';
	
	
	 
	// And the absolute required configurations for sending HTML with attachement
	 
	$mail->AddAddress("kangnarender@gmail.com");
	$mail->Subject = $subject;
	$mail->MsgHTML($message1);
	//$mail->AddAttachment("output/".$invoice_number.".jpg");
	if(!$mail->Send()) {
	$message = "There was an error sending the message";
	exit;
	}
	echo "<script type='text/javascript'>alert('Your message sent successfully!')</script>";
}
?>
				</div>
				<div class="col-md-6 p-b-30" style="border-left:1px solid #eee"><h4 class="m-text26 p-b-36 p-t-15 text-center" style="border-bottom:1px solid #eee">Contact us</h4> 
			<form class="s-text7">
            <legend><span class="glyphicon glyphicon-globe"></span> GiftsCome</legend>
            <address>
               Twitter, Inc.<br>
                795 Folsom Ave, Suite 600<br>
                San Francisco, CA 94107<br>
                <abbr title="Phone">
                    P:</abbr>
                (123) 456-7890
            </address>
               </form>
        </div>
			</div>
		</div>
		<div class="continer-fluid">
		<div class="row">
		<div class="col-md-12">
					<div class="p-r-20 p-r-0-lg" style="padding:20px; ">
						<div class="contact-map size21" id="google_map" data-map-x="26.9124" data-map-y="75.7873" data-pin="" data-scrollwhell="0" data-draggable="1" style="border:2px solid #ccc"></div>
					</div>
				</div></div></div>
	</section>
<?php require_once('templates/footer.php');?>
<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection -->
	<div id="dropDownSelect1"></div>
	<div id="dropDownSelect2"></div>
    <?php require_once('templates/common_js.php');?>
<!--===============================================================================================-->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAKFWBqlKAGCeS1rMVoaNlwyayu0e0YRes"></script>
	<script src="js/map-custom.js"></script>
<!--===============================================================================================-->
</body>
</html>